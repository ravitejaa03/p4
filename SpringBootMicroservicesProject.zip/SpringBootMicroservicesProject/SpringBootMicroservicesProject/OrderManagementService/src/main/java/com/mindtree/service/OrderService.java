package com.mindtree.service;

import java.util.List;

import com.mindtree.Controller.ModelRequests.OrderCancelRequest;
import com.mindtree.Controller.ModelRequests.OrderCancelResponse;
import com.mindtree.Controller.ModelRequests.OrderRequest;
import com.mindtree.Controller.ModelRequests.OrderResponse;
import com.mindtree.Entity.Order;
import com.mindtree.Exception.OrderException;

public interface OrderService {
	OrderResponse createOrder(OrderRequest orderRequest);

    public OrderResponse updateOrder(OrderRequest orderRequest) throws OrderException;

    public OrderCancelResponse cancelOrder(OrderCancelRequest orderCancelRequest) throws OrderException;

    public List<Order> viewOrders(String customerName) throws OrderException;
}

package com.mindtree.Controller;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.Controller.ModelRequests.OrderCancelRequest;
import com.mindtree.Controller.ModelRequests.OrderRequest;
import com.mindtree.Exception.OrderException;
import com.mindtree.service.Serviceimpl.OrderServiceImpl;

@RestController
public class OrderRestApi {
	@Autowired
private OrderServiceImpl orderImpl;
	private Map<String,Object> response;
public ResponseEntity<Map<String,Object>> createOrder(@RequestBody OrderRequest orderRequest,@PathVariable String restaurantId) {

	response=new HashMap<String,Object>();
	response.put("message","orders created successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",orderImpl.createOrder(orderRequest));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
public ResponseEntity<Map<String,Object>> updateOrder(@RequestBody OrderRequest orderRequest) throws OrderException
{
	response=new HashMap<String,Object>();
	response.put("message","orders updated successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",orderImpl.updateOrder(orderRequest));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
public ResponseEntity<Map<String,Object>> cancelOrder(@RequestBody OrderCancelRequest orderCancelRequest) throws OrderException
{
	response=new HashMap<String,Object>();
	response.put("message","orders cancelled successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",orderImpl.cancelOrder(orderCancelRequest));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
public ResponseEntity<Map<String,Object>> viewOrders(@PathVariable String customerName) throws OrderException
{
	response=new HashMap<String,Object>();
	response.put("message","orders viewed successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",orderImpl.viewOrders(customerName));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}

}
package com.mindtree.Controller.ModelRequests;

import lombok.Data;

@Data
public class OrderCancelRequest {
	private String[] orderIds;
    private String customerName;
	public String[] getOrderIds() {
		return orderIds;
	}
	public void setOrderIds(String[] orderIds) {
		this.orderIds = orderIds;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
}

package com.mindtree.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.Entity.Order;
@Repository
public interface OrderRepo extends JpaRepository<Order, Integer>{

	List<Order> findByCustomerNameAndItemDetailName(String customerName, String name);

	List<Order> findByRestaurantId(String restaurantId);

	Order getByOrderIdAndCustomerName(String orderId, String customerName);

	List<Order> findByCustomerName(String customerName);

}

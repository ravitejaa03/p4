package com.mindtree.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Dto.dtoimpl.MenuItemDtoImpl;
import com.mindtree.Model.MenuItem;
import com.mindtree.Repository.MenuItemRepo;
import com.mindtree.service.MenuItemService;
@Service
public class MenuItemServiceImpl implements MenuItemService {
@Autowired
MenuItemDtoImpl itemDto;
	@Override
	public List<MenuItem> findAllMenusByRestaurantId(String restaurentId) {
		// TODO Auto-generated method stub
		List<MenuItem> items=itemDto.findAllMenusByRestaurantId(restaurentId);
		return items ;
	}

	@Override
	public MenuItem createMenuItem(MenuItem menuItem) {
		// TODO Auto-generated method stub
		MenuItem items=itemDto.createMenuItem(menuItem);
		return items;
	}

	@Override
	public List<MenuItem> findAllByRestaurantIdAndName(String restaurantId, String name) {
		// TODO Auto-generated method stub
		List<MenuItem> items=itemDto.findAllByRestaurantIdAndName(restaurantId, name);
		return items;
	}

	@Override
	public List<MenuItem> findByName(String name) {
		// TODO Auto-generated method stub
		List<MenuItem> items=itemDto.findByName(name);
		return items;
	}

}

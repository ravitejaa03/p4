package com.mindtree.Dto;

import java.util.List;

import com.mindtree.Model.Restaurent;

public interface RestaurentDto {
	public Restaurent createRestaurent(Restaurent restaurent);
	public List<Restaurent> getRestaurentByName(String name);
	public List<Restaurent> getRestaurentByLocation(String location);
	public List<Restaurent> getRestaurentByDistance(int distance);
	public List<Restaurent> getRestaurentByCuisine(String cuisine);
	public List<Restaurent> getRestaurentByBudget(int budget);
}

package com.mindtree.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.Dto.RestaurentDto;
import com.mindtree.Model.Restaurent;
import com.mindtree.service.RestaurentService;
@Service
public class RestaurentServiceImpl implements RestaurentService {
@Autowired
private RestaurentDto restaurentDto;
	@Override
	public Restaurent createRestaurent(Restaurent restaurent) {
		// TODO Auto-generated method stub
		Restaurent res = restaurentDto.createRestaurent(restaurent);
		return res;
		
	}

	@Override
	public List<Restaurent> getRestaurentByName(String name) {
		// TODO Auto-generated method stub
		List<Restaurent> res=restaurentDto.getRestaurentByName(name);
		return res;
	}

	@Override
	public List<Restaurent> getRestaurentByLocation(String location) {
		// TODO Auto-generated method stub
		List<Restaurent> res=restaurentDto.getRestaurentByLocation(location);
		return res;
	}

	@Override
	public List<Restaurent> getRestaurentByDistance(int distance) {
		// TODO Auto-generated method stub
		List<Restaurent> res=restaurentDto.getRestaurentByDistance(distance);
		return res;
	}

	@Override
	public List<Restaurent> getRestaurentByCuisine(String cuisine) {
		// TODO Auto-generated method stub
		List<Restaurent> res=restaurentDto.getRestaurentByCuisine(cuisine);
		return res;
	}

	@Override
	public List<Restaurent> getRestaurentByBudget(int budget) {
		// TODO Auto-generated method stub
		List<Restaurent> res=restaurentDto.getRestaurentByBudget(budget);
		return res;
	}

}

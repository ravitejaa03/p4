package com.mindtree.Dto.dtoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mindtree.Dto.MenuItemDto;
import com.mindtree.Model.MenuItem;
import com.mindtree.Repository.MenuItemRepo;
@Component
public class MenuItemDtoImpl implements MenuItemDto{
@Autowired
private MenuItemRepo itemRepo;
	@Override
	public List<MenuItem> findAllByRestaurantIdAndName(String restaurantId, String name) {
		// TODO Auto-generated method stub
		return itemRepo.findAllByRestaurantIdAndName(restaurantId, name);
	}

	@Override
	public List<MenuItem> findByName(String name) {
		// TODO Auto-generated method stub
		return itemRepo.findByName(name);
	}

	@Override
	public MenuItem createMenuItem(MenuItem menuItem) {
		// TODO Auto-generated method stub
		return itemRepo.save(menuItem);
	}

	@Override
	public List<MenuItem> findAllMenusByRestaurantId(String restaurantId) {
		// TODO Auto-generated method stub
		return itemRepo.findAllMenusByRestaurantId(restaurantId);
	}

}

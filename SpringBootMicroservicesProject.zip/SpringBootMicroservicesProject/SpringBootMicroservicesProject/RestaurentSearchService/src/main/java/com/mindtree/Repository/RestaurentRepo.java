package com.mindtree.Repository;

import java.util.List;

import javax.persistence.Id;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mindtree.Model.Restaurent;

public interface RestaurentRepo extends JpaRepository<Restaurent,Integer> {
	@Query("select r from Restaurent r where r.name=?1")
  public List<Restaurent> findByName(@Param("name") String name);

	@Query("select r from Restaurent r where r.location=?1")
   public List<Restaurent> findByLocation(@Param("location") String location);
	@Query("select r from Restaurent r where r.distance=?1")
 public List<Restaurent> findByDistance(@Param("distance") int distance);
	@Query("select r from Restaurent r where r.cuisine=?1")
  public List<Restaurent> findByCuisine(@Param("cuisine") String cuisine);
	@Query("select r from Restaurent r where r.budget=?1")
   public List<Restaurent> findByBudget(@Param("budget") int budget);
}

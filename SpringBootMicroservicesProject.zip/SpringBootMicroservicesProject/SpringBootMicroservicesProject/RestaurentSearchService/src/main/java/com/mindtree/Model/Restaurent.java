package com.mindtree.Model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Restaurent {
@Id
@Column(unique = true, length = 100)
private String id;
@Column(unique = true, length = 100)
private String restaurentId;
@Column(unique = true, length = 100)
private String name;
@Column(unique = true, length = 100)
private String location;
@Column(unique = true, length = 100)
int distance;
@Column(unique = true, length = 100)
String cuisine;
@Column(unique = true, length = 100)
int budget;

public Restaurent() {
	super();
	// TODO Auto-generated constructor stub
}

public Restaurent(String id, String restaurentId, String name, String location, int distance, String cuisine,
		int budget) {
	super();
	this.id = id;
	this.restaurentId = restaurentId;
	this.name = name;
	this.location = location;
	this.distance = distance;
	this.cuisine = cuisine;
	this.budget = budget;
}

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getRestaurentId() {
	return restaurentId;
}
public void setRestaurentId(String restaurentId) {
	this.restaurentId = restaurentId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getDistance() {
	return distance;
}
public void setDistance(int distance) {
	this.distance = distance;
}
public String getCuisine() {
	return cuisine;
}
public void setCuisine(String cuisine) {
	this.cuisine = cuisine;
}
public int getBudget() {
	return budget;
}
public void setBudget(int budget) {
	this.budget = budget;
}

}

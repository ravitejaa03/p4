package com.mindtree.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.Model.MenuItem;
import com.mindtree.Model.Restaurent;

import com.mindtree.service.serviceimpl.MenuItemServiceImpl;
import com.mindtree.service.serviceimpl.RestaurentServiceImpl;
@RestController
public class RestaurentSearchApi {
@Autowired
private RestaurentServiceImpl restaurentImpl;
@Autowired
private MenuItemServiceImpl itemImpl;
private Map<String,Object> response;
@PostMapping("createRestaurents")
public ResponseEntity<Map<String,Object>> createRestaurent(@RequestBody Restaurent restaurent) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents added successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",restaurentImpl.createRestaurent(restaurent));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("getRestaurentsByName/{name}")
public ResponseEntity<Map<String,Object>>getRestaurentByName(@PathVariable String name) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents found by name");
	response.put("status",HttpStatus.OK);
	response.put("body",restaurentImpl.getRestaurentByName(name));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("/getRestaurentsByLocation/{location}")
public ResponseEntity<Map<String,Object>>getRestaurentByLocation(@PathVariable String location) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents found by location");
	response.put("status",HttpStatus.OK);
	response.put("body",restaurentImpl.getRestaurentByLocation(location));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("/getRestaurentsByDistance/{distance}")
public ResponseEntity<Map<String,Object>>getRestaurentByDistance(@PathVariable int distance) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents found by distance");
	response.put("status",HttpStatus.OK);
	response.put("body",restaurentImpl.getRestaurentByDistance(distance));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("/getRestaurentsByCuisine/{cuisine}")
public ResponseEntity<Map<String,Object>>getRestaurentBycuisine(@PathVariable String cuisine) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents found by cuisine");
	response.put("status",HttpStatus.OK);
	response.put("body",restaurentImpl.getRestaurentByCuisine(cuisine));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("/getRestaurentsByBudget/{budget}")
public ResponseEntity<Map<String,Object>>getRestaurentByBudget(@PathVariable int budget) {

	response=new HashMap<String,Object>();
	response.put("message","restaurents found by budget");
	response.put("status",HttpStatus.OK);
	response.put("body", restaurentImpl.getRestaurentByBudget(budget));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@PostMapping("createMenuItems")
public ResponseEntity<Map<String, Object>> createMenuItem(@RequestBody MenuItem menuItem) {
	response=new HashMap<String,Object>();
	response.put("message","restaurents added successfully");
	response.put("status",HttpStatus.OK);
	response.put("body",itemImpl.createMenuItem(menuItem));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("findAllMenusByRestaurentId/{restaurantId}")
public ResponseEntity<Map<String,Object>>findAllMenusByRestaurantId(@PathVariable String restaurantId) {

	response=new HashMap<String,Object>();
	response.put("message","menuitems list by restaurentId");
	response.put("status",HttpStatus.OK);
	response.put("body", itemImpl.findAllMenusByRestaurantId(restaurantId));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("findAllMenusByRestaurentIdAndName/{restaurantId}{name}")
public ResponseEntity<Map<String,Object>>findAllByRestaurantIdAndName(@PathVariable String restaurantId,@PathVariable String name) {

	response=new HashMap<String,Object>();
	response.put("message","menuitems list by restaurentId and name");
	response.put("status",HttpStatus.OK);
	response.put("body", itemImpl.findAllByRestaurantIdAndName(restaurantId,name));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
@GetMapping("findByName/{name}")
public ResponseEntity<Map<String,Object>>findByName(@PathVariable String name) {

	response=new HashMap<String,Object>();
	response.put("message","menuitems list by name");
	response.put("status",HttpStatus.OK);
	response.put("body", itemImpl.findByName(name));
	response.put("error", false);
	return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
}
}

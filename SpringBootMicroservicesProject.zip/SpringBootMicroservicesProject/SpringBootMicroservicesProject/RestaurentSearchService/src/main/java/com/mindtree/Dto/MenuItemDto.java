package com.mindtree.Dto;

import java.util.List;

import com.mindtree.Model.MenuItem;
public interface MenuItemDto {
public List<MenuItem> findAllByRestaurantIdAndName( String restaurantId,String name);

    
    public List<MenuItem> findByName(String name);

    public MenuItem createMenuItem(MenuItem menuItem);
    List<MenuItem> findAllMenusByRestaurantId(String restaurantId);
}
	


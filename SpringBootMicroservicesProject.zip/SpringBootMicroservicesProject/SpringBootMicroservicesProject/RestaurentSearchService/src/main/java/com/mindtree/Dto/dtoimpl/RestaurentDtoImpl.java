package com.mindtree.Dto.dtoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mindtree.Dto.RestaurentDto;
import com.mindtree.Model.Restaurent;
import com.mindtree.Repository.RestaurentRepo;
@Component
public class RestaurentDtoImpl implements RestaurentDto {
@Autowired
RestaurentRepo restaurentRepo;
@Override
public Restaurent createRestaurent(Restaurent restaurent) {
	// TODO Auto-generated method stub
	
	return restaurentRepo.save(restaurent);
}

@Override
public List<Restaurent> getRestaurentByName(String name) {
	// TODO Auto-generated method stub
	return restaurentRepo.findByName(name);
}

@Override
public List<Restaurent> getRestaurentByLocation(String location) {
	// TODO Auto-generated method stub
	return restaurentRepo.findByLocation(location);
}

@Override
public List<Restaurent> getRestaurentByDistance(int distance) {
	// TODO Auto-generated method stub
	return restaurentRepo.findByDistance(distance);
}

@Override
public List<Restaurent> getRestaurentByCuisine(String cuisine) {
	// TODO Auto-generated method stub
	return restaurentRepo.findByCuisine(cuisine);
}

@Override
public List<Restaurent> getRestaurentByBudget(int budget) {
	// TODO Auto-generated method stub
	return restaurentRepo.findByBudget(budget);
}

}

package com.mindtree.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.mindtree.Model.MenuItem;
@Repository
public interface MenuItemRepo extends JpaRepository<MenuItem,Integer>{

    
    public List<MenuItem> findAllByRestaurantIdAndName(@Param("restaurantId") String restaurantId, @Param("name") String name);

    
    public List<MenuItem> findByName(@Param("name") String name);

    
    List<MenuItem> findAllMenusByRestaurantId(@Param("restaurantId") String restaurantId);
}

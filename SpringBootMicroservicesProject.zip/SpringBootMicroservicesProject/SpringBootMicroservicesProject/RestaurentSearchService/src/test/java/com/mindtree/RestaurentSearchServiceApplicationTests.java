package com.mindtree;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import com.mindtree.Model.MenuItem;
import com.mindtree.Model.Restaurent;
import com.mindtree.Repository.MenuItemRepo;
import com.mindtree.Repository.RestaurentRepo;

@SpringBootTest
class RestaurentSearchServiceApplicationTests {

	@Autowired
	private RestaurentRepo repo;
	private MenuItemRepo menuRepo;
	@Test
	@Rollback
	public void testCreateRestaurent() {
		Restaurent restaurent=new Restaurent("101","101A","barista","hyderabad",100,"italian",100);
		Restaurent savedRestaurent=repo.save(restaurent);
		//Assert the response
		assertNotNull(savedRestaurent);
	}
	@Test
	public void testgetRestaurentByName()
	{
		String name="barista";
		Restaurent restaurent=(Restaurent) repo.findByName(name);
		//Assert the response
		assertThat(restaurent.getName()).isEqualTo(name);
	}
	@Test
	public void testgetRestaurentByLocation()
	{
		String location="hyderabad";
		Restaurent restaurent=(Restaurent) repo.findByLocation(location);
		//Assert the response
		assertThat(restaurent.getLocation()).isEqualTo(location);
	}@Test
	public void testgetRestaurentByDistance()
	{
		int distance=100;
		Restaurent restaurent=(Restaurent) repo.findByDistance(distance);
		//Assert the response
		assertThat(restaurent.getDistance()).isEqualTo(distance);
	}@Test
	public void testgetRestaurentByBudget()
	{
		int budget=200;
		Restaurent restaurent=(Restaurent) repo.findByBudget(budget);
		//Assert the response
		assertThat(restaurent.getBudget()).isEqualTo(budget);
	}@Test
	public void testgetRestaurentByCuisine()
	{
		String cuisine="italian";
		Restaurent restaurent=(Restaurent) repo.findByCuisine(cuisine);
		//Assert the response
		assertThat(restaurent.getCuisine()).isEqualTo(cuisine);
	}
	@Test
	public void testCreateMenuItems()
	{
		MenuItem menuItem=new MenuItem("101","101A","biryani","spicyfood",200);
		MenuItem savedMenuItem=menuRepo.save(menuItem);
		assertNotNull(savedMenuItem);
	}
	@Test
	public void testFindByName()
	{
		String name="biryani";
		MenuItem menuItem=(MenuItem) menuRepo.findByName(name);
		assertThat(menuItem.getName()).isEqualTo(name);
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	